export interface Admin {
  admin_id: number;
  full_name: String;
  email: String;
  password: String;
}
