export interface Product {
  product_id: number;
  product_name: String;
  msrp: String;
  url: String;
}
